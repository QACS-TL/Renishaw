﻿using System;
using System.IO;
using System.Xml.Serialization;
using XMLReadAndWrite;

public class Program
{
    public static void Main(string[] args)
    {
        // Create an instance of Movie
        Movie movie = new Movie
        {
            Title = "Inception",
            Director = "Christopher Nolan",
            ReleaseYear = 2010,
            Rating = 8.8
        };

        string filePath = "movie.xml";

        // Serialize the movie to XML and save it to a file
        SerializeToXml(movie, filePath);

        // Deserialize the XML back into a Movie object
        Movie deserializedMovie = DeserializeFromXml(filePath);

        // Output the deserialized movie details
        Console.WriteLine($"Title: {deserializedMovie.Title}");
        Console.WriteLine($"Director: {deserializedMovie.Director}");
        Console.WriteLine($"Release Year: {deserializedMovie.ReleaseYear}");
        Console.WriteLine($"Rating: {deserializedMovie.Rating}");
    }

    public static void SerializeToXml(Movie movie, string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(Movie));

        using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        {
            serializer.Serialize(fileStream, movie);
        }

        Console.WriteLine($"Movie serialized to {filePath}");
    }

    public static Movie DeserializeFromXml(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(Movie));

        using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
        {
            return (Movie)serializer.Deserialize(fileStream);
        }
    }
}
