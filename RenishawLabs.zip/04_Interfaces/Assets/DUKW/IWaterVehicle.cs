﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceProject.DUKW
{
    public interface IWaterVehicle
    {
        void Brake();
    }
}
