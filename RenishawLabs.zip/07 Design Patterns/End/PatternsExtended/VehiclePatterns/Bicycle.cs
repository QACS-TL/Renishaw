﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehiclePatterns
{
    internal class Bicycle : IVehicle
    {
        public string Owner => throw new NotImplementedException();

        public event Action<IVehicle> OnChange;

        public void Add(IVehicle vehicle)
        {
            throw new NotImplementedException();
        }

        public void DisplayStatus()
        {
            throw new NotImplementedException();
        }

        public void Remove(IVehicle vehicle)
        {
            throw new NotImplementedException();
        }

        public void StartEngine()
        {
            throw new NotImplementedException();
        }

        public void StopEngine()
        {
            throw new NotImplementedException();
        }
    }
}
