﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehiclePatterns
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace VehiclePatterns
    {
        public class MotorCycle : IVehicle
        {
			// implement interface and add code to the DisplayStatus, StartEngine and StopEngine methods that output information to the console 
			// for example in the StartEngine method add Console.WriteLine("Motorcycle engine started");
			// also invoke the onchange event those 3 methods 
			//e.g. OnChange?.Invoke(this);
		}
	}

}
