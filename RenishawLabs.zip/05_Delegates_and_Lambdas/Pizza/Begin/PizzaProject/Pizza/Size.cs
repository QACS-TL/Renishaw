﻿

namespace PizzaProject
{
    public enum Size
    {
        Small_10, Medium_15, Large_20
    }
}
