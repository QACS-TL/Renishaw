﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooLibrary
{
    //NOT NEEDED ANYMORE
    //public class AnimalNameComparer : IComparer<Animal>
    //{
    //    public int Compare(Animal? x, Animal? y)
    //    {
    //        return x.Name.CompareTo(y.Name);
    //    }
    //}
}
