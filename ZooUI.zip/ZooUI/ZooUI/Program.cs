﻿using ZooLibrary;
using System.Linq;
using System.Collections;

DuckBilledPlatypus a = new DuckBilledPlatypus();
a.Name = "Gerry";
a.LimbCount = 4;

//Console.WriteLine("Enter the colour of the animal: ");
//string colour = Console.ReadLine();

//Validate colour to ensure it is genuinely a colour

//a.Colour = colour;
//a.SetColour(colour);
//Console.WriteLine(a.GetColour());
Console.WriteLine(a.Colour);


Mouse a2 = new Mouse() { Name = "Millhouse", LimbCount = 5, Colour = "Grey" };

Mouse m = new ZooLibrary.Mouse();
m.Name = "Mickey";
m.LimbCount = 4;
m.Colour = "Black and White";

DuckBilledPlatypus dbp = new ZooLibrary.DuckBilledPlatypus();
dbp.Name = "Mel";
dbp.LimbCount = 5;
dbp.Colour = "Brown";

Animal m1 = new Mouse() { Name = "Minnie", LimbCount = 2, Colour = "Black and White" };

List<Animal> animals = new List<Animal> { a, a2, m, dbp, m1 };

Console.WriteLine("******* ORIGINAL SEQUENCE *************");
foreach (Animal animal in animals)
{
    Console.WriteLine(animal);
}

Console.WriteLine("******* LIMBCOUNT SEQUENCE *************");
animals.Sort();
foreach (Animal animal in animals)
{
    Console.WriteLine(animal);
}

Console.WriteLine("************** NAME SEQUENCE *****************");
animals.Sort(Animal.GetAnimalNameComparer);
foreach (Animal animal in animals)
{
    Console.WriteLine(animal);
}

Console.WriteLine("*************** COLOUR SEQUENCE ****************");
animals.Sort(Animal.GetAnimalColourComparer);
foreach (Animal animal in animals)
{
    Console.WriteLine(animal);
}


Console.WriteLine("*************** COLOUR SEQUENCE ****************");
List<Animal> animalsByLimbCount = animals.OrderBy(a => a.LimbCount).ToList();
foreach (Animal animal in animalsByLimbCount)
{
    Console.WriteLine(animal);
}

//var animalsWithLotsOfLimbs = animals
//    .Where(a => a.LimbCount >= 4 && a.Name.StartsWith("M"))
//    .OrderBy(a => a.Name)
//    .Select(a => new { a.LimbCount, a.Name }).ToList();

//var animalsWithLotsOfLimbs2 = from ax in animals
//                              where ax.LimbCount >= 4 && ax.Name.StartsWith("M")
//                              orderby ax.Name
//                              select new { ax.LimbCount, ax.Name };
//var x = animalsWithLotsOfLimbs2.ToList();

////List<Animal> animalsWithLotsOfLimbs2 = animals.FindAll(a => a.LimbCount >= 4 && a.Name.StartsWith("M"));

//animals.Add(new DuckBilledPlatypus() { Name = "Maurice", LimbCount = 8, Colour = "Yellow" });

//foreach (var za in animalsWithLotsOfLimbs)
//{
//    Console.WriteLine($"{za.Name} has {za.LimbCount} limbs");
//} 

//Console.WriteLine("*******************************");

//animals.Remove(dbp);
//animals.Add(new DuckBilledPlatypus() { Name = "Mary", LimbCount = 7, Colour = "Yellow" });

//foreach (Animal za in animalsWithLotsOfLimbs)
//{
//    Console.WriteLine(za);
//}

