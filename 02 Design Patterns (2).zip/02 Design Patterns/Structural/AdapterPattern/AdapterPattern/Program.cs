﻿namespace AdapterPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Client().Main();
        }
    }
}
