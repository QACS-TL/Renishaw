﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherMonitorUsingDelegate
{
    internal class WeatherDataSubjectWithDelegate
    {
        public delegate void WeatherChangedHandler(float temperature, float humidity, float pressure);
        public event WeatherChangedHandler WeatherChanged;

        private float temperature;
        private float humidity;
        private float pressure;

        public void SetMeasurements(float temperature, float humidity, float pressure)
        {
            this.temperature = temperature;
            this.humidity = humidity;
            this.pressure = pressure;
            OnWeatherChanged();
        }

        public virtual void OnWeatherChanged()
        {
            WeatherChanged?.Invoke(temperature, humidity, pressure); // Notify all subscribers
        }
    }
}
