﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternUsingDelegate
{
    //Light status enum
    public enum LightStatus
    {
        Off,
        On
    }
}
